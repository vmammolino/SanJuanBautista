<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Login')); ?></div>

                <div class="card-body">
                  <form action="/login" method="POST">
                  <?php echo csrf_field(); ?>
            	        <div class="field-group">
            	          <label for="email">Email</label>
                        <input class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="email" id="email" name="email" value="">
                          <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            	        </div>

                      <div class="field-group">
                        <label for="password">Contraseña</label>
                        <input class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="password" id="password" name="password" value="">
                          <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                      <div class="form-group row">
                          <div class="col-md-6">
                  					<div class=" remember-me form-check">
                  					  <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                  						<label for="rememberMe">Recordarme</label><br>
                  					</div>
                  			</div>
                      </div>

            					<button type="submit" class="btn btn-primary" name="send"><strong>Ingresar</strong></button>
                      <a href="<?php echo e(route('password.request')); ?>">Olvidaste tu Contraseña</a>
                      <a class="btn btn-outline-secondary float-right" href="index.php">Cancelar</a>

            	      </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SjBautista_Laravel\SanJuanBautista\resources\views/auth/login.blade.php ENDPATH**/ ?>