<?php $__env->startSection('content'); ?>

  
  <?php if(auth()->guard()->guest()): ?>
    

  <?php else: ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('MODIFICACION DE POSTEO')); ?></div>
                <div class="card-body">
                    <form method="POST" action="/modifPosteos"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <input id="id" type="hidden"  name="id" value="<?php echo e($posteo->id); ?>">
                            <input id="user_id" type="hidden"  name="user_id" value="<?php echo e($posteo->user_id); ?>">
                        <div class="form-group row">
                            <label for="type_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CATEGORIA')); ?></label>
                             <select name="type_id" id="type_id" >
                              <?php switch($posteo->type_id):
                              case (1): ?>
                              <option value="1" selected>TRABAJO</option>
                              <option value="2">CAPACITACION</option>
                              <option value="3">EMPRENDIMIENTOS</option>
                              <option value="4">GRADUACION</option>
                              <?php break; ?>
                              <?php case (2): ?>
                              <option value="1">TRABAJO</option>
                              <option value="2" selected>CAPACITACION</option>
                              <option value="3">EMPRENDIMIENTOS</option>
                              <option value="4">GRADUACION</option>
                              <?php break; ?>
                              <?php case (3): ?>
                              <option value="1">TRABAJO</option>
                              <option value="2">CAPACITACION</option>
                              <option value="3"selected>EMPRENDIMIENTOS</option>
                              <option value="4">GRADUACION</option>
                              <?php break; ?>
                              <?php case (4): ?>
                              <option value="1">TRABAJO</option>
                              <option value="2">CAPACITACION</option>
                              <option value="3">EMPRENDIMIENTOS</option>
                              <option value="4"selected>GRADUACION</option>
                              <?php break; ?>
                              <?php endswitch; ?>
                             </select>
                                <?php if ($errors->has('type_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type_id'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('TITULO')); ?></label>
                            <div class="col-md-6">
                              <input id="title" type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" value="<?php echo e($posteo->title); ?>" required autocomplete="title" autofocus>
                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DESCRIPCIÓN')); ?></label>
                            <div class="col-md-6">
                              <textarea id="description" rows="4" cols="50" name="description"> <?php echo e($posteo->description); ?>


                              </textarea>
                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="link" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CONTACTO')); ?></label>

                            <div class="col-md-6">
                                <input id="link" type="text" class="form-control <?php if ($errors->has('link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('link'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="link" value="<?php echo e($posteo->link); ?>" required autocomplete="link" autofocus>

                                <?php if ($errors->has('link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('link'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="image" class="col-md-4 col-form-label text-md-right"><?php echo e(__('IMAGEN')); ?></label>
                              <img  src="/storage/posteo/<?php echo e($posteo->image); ?>" height="75" width="75" >
                            <div class="col-md-6">
                                <input id="image" type="file" class="form-control" name="image">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                MODIFICAR
                                </button>
                            </div>
                        </div>
                      </form>
                      <form class="" action="/posteoPorUser/<?php echo e(Auth::user()->id); ?>"   method="get">
                        
                        <button type="submit" class="btn btn-link">
                         <?php echo e(__('VOLVER')); ?>

                       </form>

                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SjBautista_Laravel\SanJuanBautista\resources\views/modifPosteos.blade.php ENDPATH**/ ?>