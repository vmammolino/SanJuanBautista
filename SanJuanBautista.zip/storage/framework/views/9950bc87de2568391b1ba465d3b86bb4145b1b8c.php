<?php $__env->startSection('content'); ?>

  <?php if(auth()->guard()->guest()): ?>

  <?php else: ?>

    <div class="container">
        <div class="row justify-content-center">
          <section class ="posteos">
            <h2>Bien venido "<?php echo e(Auth::user()->name); ?>".Estos son tus posteos</h2>
            <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posteo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <article class="posteo">
                <a href="/posteo/<?php echo e($posteo->id); ?>" >
                  <img  src="/storage/posteo/<?php echo e($posteo->image); ?>" height="150" width="150">
                </a>
                <a href="/posteo/<?php echo e($posteo->id); ?>" >
                  <p><?php echo e($posteo->title); ?></p>
                </a>
              </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p>'No tenemos posteos disponibles'</p>

            <?php endif; ?>

          </section>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
    <h2>QUERES AGREGAR UN NUEVO POSTEO</h2>
    <div class="">
    <a href="\abmposteos"class="btn btn-success">CARGAR NUEVO</a>
    </div>
    <div class="">
      <a href="\"class="btn btn-link">VOLVER</a>
    </div>
  </div>
  </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SjBautista_Laravel\SanJuanBautista\resources\views/posteos.blade.php ENDPATH**/ ?>