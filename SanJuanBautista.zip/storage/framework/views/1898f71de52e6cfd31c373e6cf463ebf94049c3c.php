<?php $__env->startSection('content'); ?>


  <?php if(auth()->guard()->guest()): ?>


  <?php else: ?>


<div class="container">
    <div class="row justify-content-center">
      <section class ="posteos">
        <h2>Detalle de Posteo</h2>
        <article class="posteo">
          <img  src="/storage/posteo/<?php echo e($posteo->image); ?>"height="150" width="150">
          <p><?php echo e($posteo->title); ?></p>
          <p><?php echo e($posteo->description); ?></p>
          <a href="//<?php echo e($posteo->link); ?>" target="_blank" ><?php echo e($posteo->link); ?></a>
        </article>

    
        
        <h2>Queres modificar el posteo?</h2>
        <div class="">
          <form class="" action="\modifPosteos\<?php echo e($posteo->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-success" >
              MODIFICAR
            </button>
          </form>
          <form class="" action="/borrarPosteo"   method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($posteo->id); ?>">
            <input type="hidden" name="user_id" value="<?php echo e($posteo->user_id); ?>">
            <button type="submit" class="btn btn-warning">
         <?php echo e(__('BORRAR POSTEO')); ?>

        </form>
      </div>
      <div class="">
        <a href="\"class="btn btn-link">VOLVER</a>
      </div>

    </div>
  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SjBautista_Laravel\SanJuanBautista\resources\views/detallePosteo.blade.php ENDPATH**/ ?>