 <!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Biografia</title>
    <link rel="stylesheet" href="/css/app.css">
  </head>

<body>

 

<?php $__env->startSection('content'); ?>

  <div class="container">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header"><?php echo e(__('Mi Biografía')); ?></div>
                  <div class="card-body">
                  <?php $__empty_1 = true; $__currentLoopData = $registro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biografia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="form-group row">
                      <div class="col-md-6">
                        <p>Nombre: <?php echo e($biografia->first_name); ?></p>
                      </div>
                      <div class="col-md-6">
                        <p>Apellido: <?php echo e($biografia->last_name); ?></p>
                      </div>
                      <div class="col-md-6">
                        <p>Fecha Nacimiento: <?php echo e($biografia->birth_date); ?></p>
                      </div>
                      <div class="col-md-6">
                        <p>Celular: <?php echo e($biografia->phone); ?></p>
                      </div>
                      <div class="col-md-6">
                        <p>Domicilio: <?php echo e($biografia->address); ?></p>
                      </div>
                      <div class="col-md-6">
                        <p>Localidad: <?php echo e($biografia->city); ?></p>
                      </div>
                      <div class="col-md-6">
                        <p>Estudios: <?php echo e($biografia->studies); ?></p>
                        <p>Título obtenido: <?php echo e($biografia->degree); ?></p>
                      </div>
                      <div class="col-md-4">
                        <p>Archivo con CV: </p>
                      </div>
                        <img src="/storage/cv<?php echo e($biografia->file_cv); ?>">
                    </div>

                    <form method="POST" action="/modifbiografia">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Actualizar Biografia')); ?>

                                </button>
                            </div>
                        </div>
                      </form>
                    </div>


                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="form-group row">
                      <p>No cargaste tu biografia aun</p>
                      <form method="POST" action="/altabiografia">
                          <?php echo csrf_field(); ?>
                          <div class="form-group row mb-0">
                              <div class="col-md-6 offset-md-4">
                                  <button type="submit" class="btn btn-primary">
                                      <?php echo e(__('Cargar Biografia')); ?>

                                  </button>
                              </div>
                          </div>
                        </form>
                      </div>

                  <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>

  </section>

</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SjBautista_Laravel\SanJuanBautista\resources\views/biografia.blade.php ENDPATH**/ ?>