<?php $__env->startSection('content'); ?>

  <?php if(auth()->guard()->guest()): ?>

  <?php else: ?>

    <div class="container">
        <div class="row justify-content-center">
          <section class ="posteos">
            
            <?php switch($post[1]["type_id"]):
            case (1): ?>
              <h2>Total de posteos de "Trabajo"</h2>
            <?php break; ?>
            <?php case (2): ?>
            <h2>Total de posteos de "Capacitación"</h2>
            <?php break; ?>
            <?php case (3): ?>
            <h2>Total de posteos de "Emprendimientos"</h2>
            <?php break; ?>
            <?php case (4): ?>
            <h2>Total de posteos de "Graduación"</h2>
            <?php break; ?>
            <?php endswitch; ?>
            
            <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posteo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <article class="posteo">
                <a href="/posteo/<?php echo e($posteo->id); ?>" >
                  <img  src="/storage/posteo/<?php echo e($posteo->image); ?>" height="150" width="150">
                </a>
                <a href="/posteo/<?php echo e($posteo->id); ?>" >
                  <p><?php echo e($posteo->title); ?></p>
                </a>
              </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p>'No tenemos posteos disponibles'</p>

            <?php endif; ?>

          </section>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
    <h2>QUERES AGREGAR UN NUEVO POSTEO</h2>
    <div class="">
    <a href="\abmposteos"class="btn btn-success">CARGAR NUEVO</a>
    </div>
    <div class="">
      <a href="\"class="btn btn-link">VOLVER</a>
    </div>
  </div>
  </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SjBautista_Laravel\SanJuanBautista\resources\views/posteoPorTipo.blade.php ENDPATH**/ ?>