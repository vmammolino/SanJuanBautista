<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

 <?php if(auth()->guard()->guest()): ?>
      <div class="button-container">
<!--               <img src="/imagenes_sitio/logo.png" class="logo" alt="Logo SJB" width="150" height="150">  -->

           <div class="btn-container">
             <a class="btn btn-light btn-block" href="<?php echo e(route('login')); ?>">Login</a>
           </div>
           <div class="btn-container">
             <a class="btn btn-light btn-block" href="<?php echo e(route('register')); ?>">Registrarme</a>
          </div>
     </div>

   <?php else: ?>
     <body style="background-image: none">

       
      <div class="dropdown">
        <a class="btn btn btn-outline-primary dropdown-toggle " href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img class="avatar" src="/storage/avatar/<?php echo e(Auth::user()->avatar); ?>">
          <span><?php echo e(Auth::user()->name); ?></span>
        </a>

        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
          <a class="dropdown-item" href="/biografia/<?php echo e(Auth::user()->id); ?>">Biografia</a>
          <a class="dropdown-item" href="/posteoPorUser/<?php echo e(Auth::user()->id); ?>">Mis Posteos</a>
          <form class="" action="/logout" method="post">
            <?php echo csrf_field(); ?>
            <button class="dropdown-item" type="submit" name="button">Cerrar Sesion</button>
          </form>

        </div>
      </div>

      <section class="posteos">

          <article class="post">
            <h2>OFERTAS DE TRABAJO</h2>
            <div class="photo-container">
              <a href="/posteoPorTipo/1" >
                <img class="photo" src="/imagenes_sitio/trabajo.jpg" alt="foto trabajo">
              </a>
            </div>
          </article>

          <article class="post">
            <h2>CAPACITACIONES</h2>
            <div class="photo-container">
              <a href="/posteoPorTipo/2" >
                <img class="photo" src="/imagenes_sitio/capacitacion.png" alt="foto capacitacion">
              </a>
            </div>
          </article>

          <article class="post">
            <h2>EMPRENDIMIENTOS</h2>
            <div class="photo-container">
              <a href="/posteoPorTipo/3" >
                <img class="photo" src="/imagenes_sitio/emprendimiento.jpg" alt="foto emprendimiento">
              </a>
            </div>
          </article>

          <article class="post">
            <h2>OBTENER TÍTULO</h2>
            <div class="photo-container">
              <a href="/posteoPorTipo/4" >
                <img class="photo" src="/imagenes_sitio/graduacion.jpg" alt="foto graduacion">
              </a>
            </div>
          </article>

        </section>
      <?php endif; ?>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SjBautista_Laravel\SanJuanBautista\resources\views/home.blade.php ENDPATH**/ ?>